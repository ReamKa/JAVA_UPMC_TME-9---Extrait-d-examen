import java.util.ArrayList;

public class Etudiant {
    private String nom;
    private int[] notes;
    int index = 0;
    public static ArrayList<Etudiant>listeEtudiants = new ArrayList<Etudiant>();

    public Etudiant(String nom) {
        this.nom = nom;
        notes = new int[5];
        listeEtudiants.add(this);
    }
    public String getNom(){
        return nom;
    }

    public String toString() {
        String bogosse = "";
        for (int i = 0; i < index; i++) {
            bogosse += notes[i] + " ";
        }
        return "Nom eleve : " + nom + ". Notes eleves : " + bogosse;
    }

    public void entrerNote(int note) throws TabPleinException {
        if (index >= notes.length) {
            throw new TabPleinException("Lancement TabPleinException");
        }
        notes[index] = note;
        index++;
    }
}