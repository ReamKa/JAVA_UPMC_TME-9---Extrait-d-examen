public class TabPleinException extends Exception {
    public TabPleinException(String s){
        super(s);
    }
    public String toString(){
        return "Le tableau est plein";
    }
}
