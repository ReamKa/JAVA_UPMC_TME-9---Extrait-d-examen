public class TestEtudiant {
    public static void main(String[] args) {
        int note = 0;
        Etudiant ream = null;

        for (int i = 0; i < args.length; i++) {
            try {
                note = Integer.parseInt(args[i]);
                ream.entrerNote(note);
                //System.out.print(args[i] + " est une note, ");
            } catch (TabPleinException e) {
                System.out.println("Le tableau de l'etudiant " + ream.getNom() + " est plein.");
            } catch (NumberFormatException n){
                //System.out.println(args[i] + " est un nom");
                ream = new Etudiant(args[i]);
            }
        }
        System.out.println("Les 5 etudiants : ");
        for (int i = 0; i < Etudiant.listeEtudiants.size(); i++){
            System.out.println(Etudiant.listeEtudiants.get(i));
        }
    }
}
