public class MonTableau {
    private int[] tab;
    private int igReelle = 0;

    public MonTableau(int taille) {
        tab = new int[taille];
    }

    public void ajouter(int n) throws TabPleinException {
        if (igReelle >= tab.length) {
            throw new TabPleinException("Lancement de TabPleinException");
        }
        tab[igReelle] = n;
        igReelle++;
    }


        public static void main (String[]args){
            MonTableau tableau = new MonTableau(3);
            try {
                for (int i = 0; i < 10; i++) {
                    tableau.ajouter(1);
                }
            } catch (TabPleinException e) {
                System.out.println(e.getMessage());
                System.out.println(e.toString());
            }
        }
    }