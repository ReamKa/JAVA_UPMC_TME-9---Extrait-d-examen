public class TabPleinException extends Exception{
    public TabPleinException(String s){
        super(s);
    }
    @Override
    public String toString() {
        return "Le tableau est plein";
    }
}
